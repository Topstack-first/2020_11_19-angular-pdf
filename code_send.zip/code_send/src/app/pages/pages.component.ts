import { Component, OnInit, ViewChild,HostListener, ViewChildren,ComponentFactoryResolver, QueryList,Inject,ViewContainerRef, ComponentFactory, ComponentRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { PerfectScrollbarDirective } from 'ngx-perfect-scrollbar';
import { AppSettings } from '../app.settings';
import { Settings } from '../app.settings.model';
import { MenuService } from '../theme/components/menu/menu.service';
import {BarcodeInfoComponent} from './barcode-info/barcode-info.component';
import { HttpClient, HttpHeaders} from '@angular/common/http';

//for generating pdf
import pdfMake from "pdfmake/build/pdfmake";  
import pdfFonts from "pdfmake/build/vfs_fonts"; 

//for generating barcode
import JsBarcode from 'jsbarcode/bin/JsBarcode'

pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
  providers: [ MenuService ,HttpClient]
})

export class PagesComponent implements OnInit { 
  @ViewChild('sidenav') sidenav:any;
  @ViewChild('container', { read: ViewContainerRef }) container: ViewContainerRef;

  //Informations of All Barcodes
  barcodeInfos = [
    {
      'pdf_type' : 1,
      'fnsku' : '',
    }
  ];

  //index of last barcode information
  lastIndex = 1;

  //Members for controlling UI
  @ViewChildren(PerfectScrollbarDirective) pss: QueryList<PerfectScrollbarDirective>;
  public settings:Settings;
  public menus = ['vertical', 'horizontal'];
  public menuOption:string;
  public menuTypes = ['default', 'compact', 'mini'];
  public menuTypeOption:string;
  public lastScrollTop:number = 0;
  public showBackToTop:boolean = false;
  public toggleSearchBar:boolean = false;

  //member for factorying component dynamtically
  private resolver : ComponentFactoryResolver;

  //constructor
  constructor(private factoryResolver: ComponentFactoryResolver,
              public appSettings:AppSettings, 
              public router:Router, 
              private menuService: MenuService,
              private https: HttpClient)
  {        
    this.settings = this.appSettings.settings;
    this.resolver = factoryResolver;
  }

  //predefined barcode informations
  private maxCounts = [0,1,4,1];
  private barcodeSizes = [[0,0],[250,380],[250,380],[250,380]];
  private pageSizes = [[0,0],[597.6,842.4],[597.6,842.4],[288,432]];
  private colCounts = [0,2,2,1];
  private rowCounts = [0,2,2,1];

  //Barcode Components added dynamatically
  public BCComponents: ComponentRef<BarcodeInfoComponent>[] = [];

  //shifting variable for pdf type selecting
  public pdfType : number = 1;
  public language : number = 1;
  public companyName : string = "";
  public companyAddress : string = "";
  public companyPostcode : string = "";
  public companyCity : string = "";
  public companyCountry : string = "";
  public warehouseName : string = "";
  public warehouseAddress : string = "";
  public warehousePostcode : string = "";
  public warehouseCity : string = "";
  public warehouseCountry : string = "";
  public numberOfBox : number = 1;


  //Init Functions
  ngOnInit() {
    if(window.innerWidth <= 768){
      this.settings.menu = 'vertical';
      this.settings.sidenavIsOpened = false;
      this.settings.sidenavIsPinned = false;
    }
    this.menuOption = this.settings.menu; 
    this.menuTypeOption = this.settings.menuType; 
    let str = localStorage.getItem("language");
    if(str === "")
    {
      this.language = 1;
    }
    else
    {
      this.language = parseInt(str);
    }
    
  }
  ngAfterViewInit(){
    setTimeout(() => { this.settings.loadingSpinner = false }, 300);
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) { 
        if(!this.settings.sidenavIsPinned){
          this.sidenav.close(); 
        }      
        if(window.innerWidth <= 768){
          this.sidenav.close(); 
        } 
      }                
    });
    if(this.settings.menu == "vertical")
      this.menuService.expandActiveSubMenu(this.menuService.getVerticalMenuItems());

    setTimeout(() => {
      this.barcodeInfos.forEach(barcodeInfo => {
          this.loadComponent(barcodeInfo);
      });
    });
  }
  public validate()
  {
    if(this.numberOfBox < 1)
    {
      return;
    }
    if(this.numberOfBox > this.BCComponents.length)
    {
      let newCount = this.numberOfBox - this.BCComponents.length;
      for(let i = 0;i < newCount; i++)
      {
        this.addNewBarcode();
      }
    }
    else if(this.numberOfBox < this.BCComponents.length)
    {
      let delCount = this.BCComponents.length - this.numberOfBox;
      for( let i = 0; i< delCount; i++)
      {
        const inst = this.BCComponents[this.BCComponents.length-1];
        inst.destroy();
        this.BCComponents.pop();
      }
    }
  }
  public selLanguage()
  {
    localStorage.setItem("language",this.language+"");
  }
  //create barcode information component dynamatically
  private loadComponent(barcodeInfo: any): void {
    const componentFactory = this.resolver.resolveComponentFactory(BarcodeInfoComponent);
    const componentRef = this.container.createComponent(componentFactory);
    const inst = (<BarcodeInfoComponent>componentRef.instance);
    inst.barcodeInfo = barcodeInfo;
    inst.componentRef = componentRef;
    this.BCComponents[this.BCComponents.length] = componentRef;
  }

  //this function adds new barcode component dynamatically
  public addNewBarcode()
  {
    const barcodeInfo = {
        'pdf_type': 1,
        'fnsku' : '',
    }
    this.loadComponent(barcodeInfo);
  }

  //this fucntion generates barcode image from text
  private textToBase64Barcode(text,boxNum){
    var canvas = document.createElement("canvas");

    let barcodeWidth = 500;

    //barcode height (pixels)
    let barcodeHeight = 760;

    //set width and height of canvas
    canvas.width = barcodeWidth;
    canvas.height = barcodeHeight;

    let drawingRectWidth = canvas.width;
    let drawingRectHeight = canvas.height / 2;
    let topLineHeight = drawingRectHeight * 0.1;
    let topLineWeight = 4;
    let midLineHeight = drawingRectHeight * 0.4;
    let midLineWeight = 14;
    let bottomLineHeight = drawingRectHeight * 0.8;
    let bottomLineWeight = topLineWeight;
    let barcodeDrawingHeight = drawingRectHeight * 0.3;
    let barcodePosY = drawingRectHeight * 0.47;

    //draw all
    const ctx = canvas.getContext('2d');
    
    //draw top horizontal line
    ctx.fillStyle = "#000000";
    ctx.fillRect(0,topLineHeight,drawingRectWidth,topLineWeight);
    
    //draw mid horizontal line
    ctx.fillStyle = "#000000";
    ctx.fillRect(0,midLineHeight,drawingRectWidth,midLineWeight);

    //draw bottom horizontal line
    ctx.fillStyle = "#000000";
    ctx.fillRect(0,bottomLineHeight,drawingRectWidth,bottomLineWeight);

       
    //draw top 1 text
    ctx.font = "24px Arial";
    let shoppingLabel = this.language == 1 ? "SHIPPING LABEL":"ÉTIQUETTE D'EXPÉDITION";
    ctx.fillText(shoppingLabel,4,topLineHeight-3);

    ctx.font = "30px Arial";
    let box3 = this.language == 1 ? "Box "+boxNum : "Carton n° "+boxNum;
    ctx.fillText(box3,drawingRectWidth - 15 * box3.length-2,topLineHeight-3);
    
    //ship from
    ctx.font = "16px Arial";
    let shipFrom = this.language == 1 ? "SHIP FROM:":"Expediteur";
    ctx.fillText(shipFrom,4,topLineHeight + 20);
    
    //companyName
    let companyName = this.companyName;
    ctx.fillText(companyName,4,topLineHeight + 36);
    
    //companyAddress
    let companyAddress = this.companyAddress;
    ctx.fillText(companyAddress,4,topLineHeight + 52);
    
    //postcode
    let postcode = this.companyPostcode;
    let companyCity = this.companyCity;
    ctx.fillText(companyCity +", " + postcode,4,topLineHeight + 68);
    
    //postcode
    let companyCountry = this.companyCountry;
    ctx.fillText(companyCountry,4,topLineHeight + 84);
    
     //ship to
    let shipTo = this.language == 1?"SHIP TO:" : "Destinataire";
    ctx.fillText(shipTo,barcodeWidth/2 - 20,topLineHeight + 20);
    
    //companyName
    let warehouseName = this.warehouseName;
    ctx.fillText(warehouseName,barcodeWidth/2 - 20,topLineHeight + 36);
    
    //companyAddress
    let warehouseAddress = this.warehouseAddress;
    ctx.fillText(warehouseAddress,barcodeWidth/2 - 20,topLineHeight + 52);

    //companyAddress
    let warehouseCity = this.warehouseCity;
    ctx.fillText(warehouseCity,barcodeWidth/2 - 20,topLineHeight + 68);
    
    //postcode
    let warehousePostcode = this.warehousePostcode;
    ctx.fillText(warehousePostcode,barcodeWidth/2 - 20,topLineHeight + 84);
    
    //country
    let warehouseCountry = this.warehouseCountry;
    ctx.fillText(warehouseCountry,barcodeWidth/2 - 20,topLineHeight + 100);
    
    //publish date
    let date = new Date();
    let dateStr = date.getDay()+"."+date.getMonth()+"."+date.getFullYear()+", "+date.getHours()+":"+date.getMinutes();
    let publishDate = "FBA("+dateStr+")";
    ctx.font = "10px Arial";
    ctx.fillStyle = "white";
    ctx.fillText(publishDate,4,midLineHeight + 10);
    
    //country
    let bottomText = this.language == 1? "PLEASE LEAVE THIS LABEL UNCOVERED" : "VEUILLEZ LAISSER CETTE ÉTIQUETTE VISIBLE";
    ctx.font = "20px Arial";
    ctx.fillStyle = "black";
    ctx.fillText(bottomText,(drawingRectWidth-12*bottomText.length)/2,drawingRectHeight-20);

    let barcodeImage = this.getBarcodeImage(text, drawingRectWidth,barcodeDrawingHeight);
    if(barcodeImage.width > drawingRectWidth * 0.8)
    {
      ctx.drawImage(barcodeImage,(drawingRectWidth - drawingRectWidth * 0.8) / 2,barcodePosY,drawingRectWidth * 0.8,barcodeDrawingHeight);
    }
    else{
      ctx.drawImage(barcodeImage,(drawingRectWidth - barcodeImage.width) / 2,barcodePosY,barcodeImage.width,barcodeDrawingHeight);
    }
    
    return canvas.toDataURL("image/png");
  }
  private getBarcodeImage(text,bcWidth,bcHeight)
  {
    var canvas = document.createElement("canvas");
    
    JsBarcode(canvas, text, {
      format: "code128",
      width:2,
      margin:10,
      height:bcHeight,
      border:0,
      outline:"none"
    });
    canvas.style.border = "0px none black";
    canvas.style.outline = "none";
    return canvas;
  }

  //this function generate pdf with all barcodes
  public generatePdf()
  {
    //variable for containing barcode datas
    let content = [];

    //Max Count for placing on a paper
    let maxCountPerPage = this.maxCounts[this.pdfType];

    //barcode width (pixels)
    let barcodeWidth = this.barcodeSizes[this.pdfType][0];

    //barcode height (pixels)
    let barcodeHeight = this.barcodeSizes[this.pdfType][1];

    //page width (pixels)
    let pageWidth = this.pageSizes[this.pdfType][0];

    //page height pixels
    let pageHeight = this.pageSizes[this.pdfType][1];

    //column count for placing barcodes
    let bcColCount = this.colCounts[this.pdfType] ;

    //row count for placing barcodes
    let bcRowCount = this.rowCounts[this.pdfType];

    //breath padding variable
    let paddingWidth = (pageWidth - bcColCount * barcodeWidth) / (bcColCount + 1);
   
    //height padding varible
    let paddingHeight = (pageHeight - bcRowCount * barcodeHeight) / (bcRowCount + 1);
    let pageMargin = 0;
    console.log("paddingWidth="+paddingWidth);
    console.log("paddingHeight="+paddingHeight);
    //index for loop and indexing
    let loop_index = 0;

    //construct barcode images for all barcodes
    this.BCComponents.forEach(bc_component => {

      const inst = (<BarcodeInfoComponent>bc_component.instance);

      //coordinate of durrent barcode
      let x = 0;
      let y = 0;
      console.log("pdfType = "+this.pdfType+",");
      if(this.pdfType == 1 || this.pdfType == 3)
      {
        x = paddingWidth;
        y = paddingHeight;
      }
      else if(this.pdfType == 2)
      {
        x = (loop_index % bcColCount) * barcodeWidth + paddingWidth * (loop_index % bcColCount + 1);
        y = paddingHeight + (barcodeHeight + paddingHeight) * (Math.floor(loop_index / bcColCount) % bcRowCount);
      }
      
      console.log("x = "+x+",y = "+y);
      //content of one barcode
      content[loop_index] = {
        image: this.textToBase64Barcode(inst.barcodeInfo.fnsku,loop_index+1),
        width: barcodeWidth,
        height: barcodeHeight,
        absolutePosition: {
          x:x,
          y:y
        },
        pageBreak: ''
      };

      //page control
      console.log("loop="+loop_index+",max="+maxCountPerPage);
      if(loop_index > 0 && loop_index % maxCountPerPage === 0)
      {
        content[loop_index]["pageBreak"] = 'before';
      }
      loop_index++;
    });

    //pdf document infomation
    const documentDefination ={
      pageSize: {width: pageWidth, height: pageHeight},
      pageMargins: [ pageMargin, pageMargin, pageMargin, pageMargin ],
      content: content
      };
      pdfMake.createPdf(documentDefination).download();
  }
}
