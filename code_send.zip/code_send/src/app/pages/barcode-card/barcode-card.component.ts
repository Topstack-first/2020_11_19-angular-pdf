import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import * as html2canvas from 'html2canvas';

@Component({
  selector: 'app-barcode-card',
  templateUrl: './barcode-card.component.html',
  styleUrls: ['./barcode-card.component.scss']
})
export class BarcodeCardComponent implements OnInit {
  @ViewChild('barcode') screen: ElementRef;
  constructor() { }

  ngOnInit(): void {
  }
  public html2Canvas()
  {
    
  }
}
